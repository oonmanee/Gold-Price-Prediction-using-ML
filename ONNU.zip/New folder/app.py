import streamlit as st
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error

# Sample data (replace with actual dataset)
data = {
    'area_type': ['Urban', 'Urban', 'Rural', 'Urban'],
    'availability': ['Ready to Move', 'Under Construction', 'Ready to Move', 'Ready to Move'],
    'location': ['Location1', 'Location2', 'Location3', 'Location1'],
    'size': ['2 BHK', '3 BHK', '2 BHK', '3 BHK'],
    'society': ['Yes', 'No', 'Yes', 'Yes'],
    'total_sqft': [1200, 1500, 1100, 1300],
    'bath': [2, 3, 2, 3],
    'balcony': [1, 2, 1, 1],
    'price': [5000000, 6000000, 4000000, 5500000],
    'bhk': [2, 3, 2, 3]
}

# Convert to DataFrame
df = pd.DataFrame(data)

# Preprocessing
df = pd.get_dummies(df, columns=['area_type', 'availability', 'location', 'size', 'society'], drop_first=True)

# Features and target
X = df.drop('price', axis=1)
y = df['price']

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train_scaled, y_train)

# Streamlit App
st.title('🏠 House Price Prediction App')
st.subheader("Enter House Details Below")

# User Input Fields
area_type = st.selectbox('Area Type', ['Urban', 'Rural'])
availability = st.selectbox('Availability', ['Ready to Move', 'Under Construction'])
location = st.selectbox('Location', ['Location1', 'Location2', 'Location3'])
size = st.selectbox('Size', ['2 BHK', '3 BHK', '4 BHK'])
society = st.selectbox('Society', ['Yes', 'No'])
total_sqft = st.number_input('Total Square Footage', min_value=500, max_value=5000, step=100)
bath = st.number_input('Number of Bathrooms', min_value=1, max_value=5, step=1)
balcony = st.number_input('Number of Balconies', min_value=0, max_value=3, step=1)
bhk = st.number_input('Number of Bedrooms', min_value=1, max_value=5, step=1)

# Prepare input
user_data = {
    'area_type_Urban': [1 if area_type == 'Urban' else 0],
    'availability_Under Construction': [1 if availability == 'Under Construction' else 0],
    'location_Location1': [1 if location == 'Location1' else 0],
    'location_Location2': [1 if location == 'Location2' else 0],
    'location_Location3': [1 if location == 'Location3' else 0],
    'size_3 BHK': [1 if size == '3 BHK' else 0],
    'size_4 BHK': [1 if size == '4 BHK' else 0],
    'society_Yes': [1 if society == 'Yes' else 0],
    'total_sqft': [total_sqft],
    'bath': [bath],
    'balcony': [balcony],
    'bhk': [bhk]
}

user_df = pd.DataFrame(user_data)
user_df = user_df.reindex(columns=X.columns, fill_value=0)

# Prediction Button
if st.button('Predict Price'):
    user_data_scaled = scaler.transform(user_df)
    predicted_price = model.predict(user_data_scaled)[0]
    st.markdown(f"### 🏡 Predicted House Price: **₹{predicted_price:,.2f}**")

# Show model performance
y_pred = model.predict(X_test_scaled)
mae = mean_absolute_error(y_test, y_pred)
st.write(f"📊 Mean Absolute Error (MAE) of the model: ₹{mae:,.2f}")
